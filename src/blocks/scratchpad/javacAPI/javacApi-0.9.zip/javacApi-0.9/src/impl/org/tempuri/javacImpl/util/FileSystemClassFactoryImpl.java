/*
Copyright (c) 2002 Christopher Oliver

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
copies of the Software, and to permit persons to whom the Software is 
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in 
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
THE SOFTWARE.
*/
package org.tempuri.javacImpl.util;
import org.tempuri.javac.util.FileSystemClassFactory;
import org.tempuri.javac.JavaClassReaderFactory;
import org.tempuri.javac.JavaClassReader;
import org.tempuri.javac.JavaClassWriterFactory;
import org.tempuri.javac.JavaClassWriter;
import org.tempuri.javac.JavaSourceReaderFactory;
import org.tempuri.javac.JavaSourceReader;
import java.util.jar.JarFile;
import java.util.jar.JarEntry;
import java.io.*;
import java.net.*;
import java.util.*;


public class FileSystemClassFactoryImpl implements FileSystemClassFactory {

    public String makeClassName(String fileName) throws IOException {
	File origFile = new File(fileName);
	String canonical = null;
	if (origFile.exists()) {
	    canonical = origFile.getCanonicalPath().replace('\\', '/');
	}
	String str = fileName;
	str = str.replace('\\', '/');
	for (int i = 0; i < sourcePath.length; i++) {
	    String prefix = 
		sourcePath[i].getCanonicalPath().replace('\\', '/');
	    if (canonical != null) {
		if (canonical.startsWith(prefix)) {
		    String result = canonical.substring(prefix.length() + 1,
							canonical.length() -5);
		    result = result.replace('/', '.');
		    return result;
		}
	    } else {
		File t = new File(sourcePath[i], fileName);
		if (t.exists()) {
		    str = t.getCanonicalPath().replace('\\', '/');
		    String result = str.substring(prefix.length()+1,
						  str.length() - 5).replace('/', '.');
		    return result;
		}
	    }
	}
	if (fileName.endsWith(".java")) {
	    fileName = fileName.substring(0, fileName.length() - 5);
	}
	fileName = fileName.replace('\\', '.');
	return fileName.replace('/', '.');
    }

    public String makeFileName(String className) throws IOException {
	String str = className;
	str = str.replace('.', '/') + ".java";
	for (int i = 0; i < sourcePath.length; i++) {
	    File t = new File(sourcePath[i], str);
	    if (t.exists()) {
		return t.getCanonicalPath();
	    }
	}
	return str;
    }

    public JavaSourceReader getSourceReader(String className) 
	throws IOException {
	String path = className.replace('.', '/') + ".java";
	for (int i = 0; i < sourcePath.length; i++) {
	    File file = sourcePath[i];
	    if (file.isDirectory()) {
		File fullpath = new File(file, path);
		if (fullpath.exists()) {
		    return new SourceReaderImpl(className, fullpath);
		}
	    } else if (file.exists()) {
		JarFile jar = 
		    (JarFile)jarCache.get(file);
		if (jar == null) {
		    jar = new JarFile(file);
		    jarCache.put(file, jar);
		}
		JarEntry entry = jar.getJarEntry(path);
		if (entry != null) {
		    return new SourceReaderImpl(className, jar, entry); 
		}
	    }
	}
	return null;
    }

    public JavaClassReader getClassReader(String className) 
	throws IOException {
	String path = className.replace('.', '/') + ".class";
	JavaClassReader result = getClassReader(className, path,
						bootClassPath);
	if (result != null) return result;
	result = getClassReader(className, path, classPath);
	return result;
    }

    private JavaClassReader getClassReader(String className,
					   String path,
					   File[] classPath) 
    	throws IOException {
	for (int i = 0; i < classPath.length; i++) {
	    File file = classPath[i];
	    if (file.isDirectory()) {
		File fullpath = new File(file, path);
		if (fullpath.exists()) {
		    return new ClassReaderImpl(className, fullpath);
					       
		}
	    } else if (file.exists()) {
		JarFile jar = 
		    (JarFile)jarCache.get(file);
		if (jar == null) {
		    jar = new JarFile(file);
		    jarCache.put(file, jar);
		}
		String entryName = className.replace('.', '/')+".class";
		JarEntry entry = jar.getJarEntry(entryName);
		if (entry != null) {
		    return new ClassReaderImpl(className, jar, entry); 
		} 
	    }
	}
	return null;
    }
    
    public JavaClassWriter getClassWriter(String className) 
	throws IOException {
	if (outputDir != null) {
	    String path = className.replace('.', '/') + ".class";
	    File file = new File(outputDir, path);
	    file.mkdirs();
	    return new ClassWriterImpl(className, file);
	} else {
	    SourceReaderImpl sourceReader = (SourceReaderImpl) 
		getSourceReader(className);
	    if (sourceReader != null) {
		String uri = sourceReader.getURI();
		if (uri.startsWith("file:") && uri.endsWith(".java")) {
		    String fileName = uri.substring(5, uri.length() - 5) + ".class";
		    return new ClassWriterImpl(className,
					       new File(fileName));
		}
	    }
	}
	String path = className.replace('.', '/') + ".class";
	File file = new File(path);
	file.mkdirs();
	return new ClassWriterImpl(className, file);
    }

    public static class SourceReaderImpl implements JavaSourceReader {

	String className;
	Reader reader;
	File file;
	JarFile jarFile;
	JarEntry jarEntry;

	public SourceReaderImpl(String className, File file) 
	    throws IOException {
	    this.className = className;
	    this.file = file;
	}

	public SourceReaderImpl(String className, 
				JarFile jarFile, JarEntry jarEntry) 
	    throws IOException {
	    this.className = className;
	    this.jarFile = jarFile;
	    this.jarEntry = jarEntry;
	}

	public String getClassName() {
	    return className;
	}

	public Reader getReader() throws IOException {
	    if (reader == null) {
		InputStream is;
		if (file != null) {
		    is = new FileInputStream(file);
		} else {
		    is = jarFile.getInputStream(jarEntry);
		}
		reader = new InputStreamReader(is);
	    }
	    return reader;
	}

	public String getURI() {
	    return file != null ? 
		("file:"+file.getAbsolutePath().replace('\\', '.')) :
		("jar:file:"+jarFile.getName() +"!/"+jarEntry.getName());
	}
    }

    public static class ClassReaderImpl implements JavaClassReader {
	String className;
	InputStream inputStream;
	File file;
	JarFile jarFile;
	JarEntry jarEntry;

	public ClassReaderImpl(String className, 
			       File file) throws IOException {
	    this.className = className;
	    this.file = file;
	}

	public ClassReaderImpl(String className, 
			       JarFile jarFile,
			       JarEntry jarEntry) throws IOException {
	    this.className = className;
	    this.jarFile = jarFile;
	    this.jarEntry = jarEntry;
	}

	public String getClassName() {
	    return className;
	}

	public InputStream getInputStream() throws IOException {
	    if (inputStream == null) {
		if (file != null) {
		    inputStream = new FileInputStream(file);
		} else {
		    inputStream = jarFile.getInputStream(jarEntry);
		}
		inputStream = new BufferedInputStream(inputStream);
	    }
	    return inputStream;
	}

	public String getURI() {
	    return file != null ? 
		("file:"+file.getAbsolutePath().replace('\\', '/')) :
		("jar:file:"+jarFile.getName() + "!/"+jarEntry.getName());
		
	}

	public String toString() {
	    return getURI();
	}
    }

    public static class ClassWriterImpl implements JavaClassWriter {
	String className;
	File file;

	ClassWriterImpl(String className, File file) {
	    this.className = className;
	    this.file = file;
	}

	public String getClassName() {
	    return className;
	}

	public void writeClass(InputStream inputStream) throws IOException {
	    if (file.exists()) {
		file.delete();
	    }
	    BufferedOutputStream b = 
		new BufferedOutputStream(new FileOutputStream(file));
	    byte[] buf = new byte[8192];
	    int count;
	    while ((count = inputStream.read(buf, 0, buf.length)) > 0) {
		b.write(buf, 0, count);
	    }
	    b.close();
	}

	public String getURI() {
	    return "file:"+file.getAbsolutePath().replace('\\', '/');
	}
    }


    public void setBootClassPath(String bcp) {
	bootClassPath = parsePath(bcp);
    }

    public void setClassPath(String cp) {
	classPath = parsePath(cp);
    }

    public void setSourcePath(String sp) {
	sourcePath = parsePath(sp);
    }

    public void setOutputDir(String outputDir) {
	this.outputDir = new File(outputDir);
    }

    private File[] parsePath(String p) {
	StringTokenizer izer = new StringTokenizer(p, File.pathSeparator);
	int count = izer.countTokens();
	File[] result = new File[count];
	int i = 0;
	while (izer.hasMoreTokens()) {
	    result[i++] = new File(izer.nextToken());
	}
	return result;
    }

    HashMap jarCache = new HashMap();
    File[] bootClassPath;
    File[] classPath;
    File[] sourcePath;
    File outputDir;

}


