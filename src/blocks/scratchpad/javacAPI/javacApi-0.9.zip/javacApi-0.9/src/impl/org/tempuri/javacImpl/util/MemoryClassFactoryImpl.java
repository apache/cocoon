/*
Copyright (c) 2002 Christopher Oliver

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
copies of the Software, and to permit persons to whom the Software is 
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in 
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
THE SOFTWARE.
*/
package org.tempuri.javacImpl.util;
import org.tempuri.javac.util.MemoryClassFactory;
import org.tempuri.javac.JavaClassReaderFactory;
import org.tempuri.javac.JavaClassReader;
import org.tempuri.javac.JavaClassWriterFactory;
import org.tempuri.javac.JavaClassWriter;
import org.tempuri.javac.JavaSourceReaderFactory;
import org.tempuri.javac.JavaSourceReader;
import org.tempuri.javac.JavaCompiler;
import org.tempuri.javacImpl.eclipse.JavaCompilerImpl;
import org.tempuri.javac.JavaCompilerErrorHandler;
import java.io.*;
import java.util.*;

public class MemoryClassFactoryImpl
    implements MemoryClassFactory {

    public class DefiningClassLoader extends ClassLoader {

	public DefiningClassLoader(ClassLoader parent) {
	    super(parent);
	}
	
	public Class defineClass(String name, byte data[]) {
	    return super.defineClass(name, data, 0, data.length);
	}

	public Class findClass(String className) 
	    throws ClassNotFoundException {
	    Map map = outputMap;
	    byte[] bytes = (byte[])map.get(className);
	    if (bytes != null) {
		return defineClass(className, bytes);
	    }
	    throw new ClassNotFoundException(className);
	}

	public InputStream getResourceAsStream(String name) {
	    String className = null;
	    if (name.endsWith(".class")) {
		className = 
		    name.substring(0, name.length() - 6).replace('/', '.');
		Map map = outputMap;
		byte[] bytes; 
		bytes = (byte[])map.get(className);
		if (bytes != null) {
		    return new ByteArrayInputStream(bytes);
		}
	    }
	    return super.getResourceAsStream(name);
	}
    }

    Map sourceMap;
    Map outputMap = Collections.synchronizedMap(new TreeMap());
    DefiningClassLoader definingClassLoader =
	new DefiningClassLoader(ClassLoader.getSystemClassLoader());

    public void setInput(Map sourceMap) {
	this.sourceMap = sourceMap;
	this.definingClassLoader = 
	    new DefiningClassLoader(definingClassLoader.getParent());
	this.outputMap = Collections.synchronizedMap(new TreeMap());
    }

    public Map getOutput() {
	return outputMap;
    }

    public JavaSourceReader getSourceReader(String className) 
	throws IOException {
	Map map = sourceMap;
	if (map == null) return null;
	Object obj = map.get(className);
	if (obj == null) {
	    return null;
	}
	return new SourceReaderImpl(className, obj.toString());
    }

    public JavaClassReader getClassReader(String className) 
	throws IOException {
	String resourceName = className.replace('.', '/') + ".class";
	InputStream strm = 
	    definingClassLoader.getResourceAsStream(resourceName);
	if (strm == null) {
	    return null;
	}
	return new ClassReaderImpl(className, strm);
    }
    
    public JavaClassWriter getClassWriter(String className) 
	throws IOException {
	return new ClassWriterImpl(className);
    }

    public class SourceReaderImpl implements JavaSourceReader {

	String className;
	String source;
	Reader reader = null;

	public SourceReaderImpl(String className, String source) {
	    this.className = className;
	    this.source = source;
	}

	public String getClassName() {
	    return className;
	}

	public Reader getReader() throws IOException {
	    if (reader == null) {
		reader = new StringReader(source);
	    }
	    return reader;
	}
    }

    public class ClassReaderImpl implements JavaClassReader {

	String className;
	InputStream inputStream;

	public ClassReaderImpl(String className, InputStream stream) {
	    this.className = className;
	    this.inputStream = stream;
	}

	public String getClassName() {
	    return className;
	}

	public InputStream getInputStream() throws IOException {
	    return inputStream;
	}
    }

    public class ClassWriterImpl implements JavaClassWriter {
	String className;
	ClassWriterImpl(String className) {
	    this.className = className;
	}

	public String getClassName() {
	    return className;
	}

	public void writeClass(InputStream inputStream) throws IOException {
	    byte[] buf = new byte[8192];
	    ByteArrayOutputStream baos = 
		new ByteArrayOutputStream(buf.length);
	    int count;
	    while ((count = inputStream.read(buf, 0, buf.length)) > 0) {
		baos.write(buf, 0, count);
	    }
	    baos.flush();
	    byte[] bytes = baos.toByteArray();
	    System.out.println("compiled: " + className);
	    outputMap.put(className, bytes);
	}
    }

    public void setClassLoader(ClassLoader cl) {
	this.definingClassLoader = new DefiningClassLoader(cl);
    }

    public Class loadClass(String className) throws ClassNotFoundException {
	return definingClassLoader.loadClass(className);
    }

}


