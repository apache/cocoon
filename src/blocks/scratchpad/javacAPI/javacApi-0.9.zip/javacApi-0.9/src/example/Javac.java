/*
Copyright (c) 2002 Christopher Oliver

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
copies of the Software, and to permit persons to whom the Software is 
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in 
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
THE SOFTWARE.
*/
package example;
import org.tempuri.javac.JavaCompiler;
import org.tempuri.javac.JavaCompilerErrorHandler;
import org.tempuri.javac.util.FileSystemClassFactory;
import java.util.List;
import java.util.Iterator;
import java.util.LinkedList;
import java.io.File;

// Note: these could be dynamically loaded
import org.tempuri.javacImpl.eclipse.JavaCompilerImpl;
import org.tempuri.javacImpl.util.FileSystemClassFactoryImpl;

/**
 * Partial simulation of the behavior of the standard javac command
 * line compiler using the JavaCompiler API
 */

public class Javac {
    
    private static void unknownOption(String option) {
	System.err.println("warning: unknown option: "+option);
    }
    
    private static void warnNotSupported(String option) {
	System.err.println("warning: unsupported option: "+option);
    }
    
    public static void main(String[] argv) throws Exception {
	String bootClassPath = System.getProperty("sun.boot.class.path");
	String classPath = System.getProperty("java.class.path");
	String sourcePath = ".";
	boolean debug = false;
	String sourceVersion = null;
	String targetVersion = null;
	String outputDir = ".";
	List fileList = new LinkedList();
	for (int i = 0; i < argv.length; i++) {
	    String arg = argv[i];
	    if (arg.startsWith("-")) {
		if (arg.startsWith("-g")) {
		    debug = !arg.equals("-g:none");
		} else if (arg.equals("-sourcepath")) {
		    if ((i + 1) < argv.length) {
			sourcePath = argv[i + 1];
			i++;
		    }
		} else if (arg.equals("-classpath")) {
		    if ((i + 1) < argv.length) {
			classPath = argv[i + 1];
			i++;
		    }
		} else if (arg.equals("-bootclasspath")) {
		    if ((i + 1) < argv.length) {
			bootClassPath = argv[i + 1];
			i++;
		    }
		} else if (arg.equals("-target")) {
		    if ((i + 1) < argv.length) {
			targetVersion = argv[i + 1];
			i++;
		    }
		    
		} else if (arg.equals("-source")) {
		    if ((i + 1) < argv.length) {
			sourceVersion = argv[i + 1];
			i++;
		    }
		} else if (arg.equals("-d")) {
		    if ((i + 1) < argv.length) {
			outputDir = argv[i + 1];
			i++;
		    }
		} else if (arg.equals("-O")) {
		    // no action
		} else if (arg.equals("-deprecation")) {
		    // no action
		    warnNotSupported(arg);
		} else if (arg.equals("-nowarn")) {
		    // no action
		} else if (arg.equals("-verbose")) {
		    // no action
		} else if (arg.equals("-extdirs")) {
		    // no action
		    warnNotSupported(arg);
		} else if (arg.equals("-encoding")) {
		    // no action
		    warnNotSupported(arg);
		} else if (arg.equals("-help")) {
		    System.out.println("Usage: javac <options> <source files>");
		    
		    System.out.println("where possible options include:");
		    System.out.println("-g                        Generate all debugging info");
		    System.out.println("-g:none                   Generate no debugging info");
		    System.out.println("-g:{lines,vars,source}    Generate only some debugging info");
		    System.out.println("-O                        Optimize; may hinder debugging or enlarge class file");

		    System.out.println("-nowarn                   Generate no warnings");
		    System.out.println("-verbose                  Output messages about what the compiler is doing");
		    System.out.println("-deprecation              Output source locations where deprecated APIs are used");
		    System.out.println("-classpath <path>         Specify where to find user class files");
		    System.out.println("-sourcepath <path>        Specify where to find input source files");
		    System.out.println("-bootclasspath <path>     Override location of bootstrap class files");
		    System.out.println("-extdirs <dirs>           Override location of installed extensions");
		    System.out.println("-d <directory>            Specify where to place generated class files");
		    System.out.println("-encoding <encoding>      Specify character encoding used by source files");
		    System.out.println("-source <release>         Provide source compatibility with specified release");
		    System.out.println("-target <release>         Generate class files for specific VM version");
		    System.out.println("-help                     Print a synopsis of standard options");
		} else {
		    unknownOption(arg);

		}
	    } else {
		String fileName = arg;
		File file = new File(fileName);
		if (!file.exists()) {
		    System.err.println("error: cannot read: "+ file);
		} else {
		    fileList.add(fileName);
		}
	    }
	}
	FileSystemClassFactory factory = new FileSystemClassFactoryImpl();
	factory.setBootClassPath(bootClassPath);
	factory.setClassPath(classPath);
	factory.setSourcePath(sourcePath);
	factory.setOutputDir(outputDir);
	JavaCompiler compiler = new JavaCompilerImpl();
	if (sourceVersion != null) {
	    compiler.setSourceVersion(sourceVersion);
	} 
	if (targetVersion != null) {
	    compiler.setTargetVersion(targetVersion);
	}
	compiler.setDebug(debug);
	String[] classNames = new String[fileList.size()];
	int i = 0;
	Iterator iter = fileList.iterator();
	while (iter.hasNext()) {
	    String fileName = (String)iter.next();
	    classNames[i++] = factory.makeClassName(fileName);
	}
	compiler.compile(classNames,
			 factory,
			 factory,
			 factory,
			 new JavaCompilerErrorHandler() {
				 public void handleError(String className,
							 int line,
							 int column,
							 Object errorMessage) {
				     String msg = className;
				     if (line > 0) {
					 msg += ": Line " + line;
				     }
				     if (column >= 0) {
					 msg += "." + column;
				     }
				     msg += ": ";
				     msg += errorMessage;
				     System.err.println(msg);
				 }
			     });

    }
    
}
