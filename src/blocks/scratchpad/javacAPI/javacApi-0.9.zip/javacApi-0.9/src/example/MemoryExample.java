/*
Copyright (c) 2002 Christopher Oliver

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
copies of the Software, and to permit persons to whom the Software is 
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in 
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
THE SOFTWARE.
*/
package example;
import org.tempuri.javac.JavaCompiler;
import org.tempuri.javac.JavaCompilerErrorHandler;
import org.tempuri.javac.util.MemoryClassFactory;
import java.util.Map;
import java.util.HashMap;
import java.io.FileInputStream;

// Note: these could be dynamically loaded
import org.tempuri.javacImpl.eclipse.JavaCompilerImpl;
import org.tempuri.javacImpl.util.MemoryClassFactoryImpl;

/**
 * Example of compling Java source in memory and loading the
 * resulting class
 */

public class MemoryExample {

    public static void main(String[] argv) throws Exception {
        String helloSource = 
            "package test;" +
            "public class Hello {" +
            "   public String greeting() {" +
            "       return \"Hello World!\";" +
            "   }" +
            "}";
        String mainSource = 
            "package test.main;" +
            "import test.Hello;" +
            "public class Main implements Runnable {" +
            "   public void run() {" +
            "       Hello hello = new Hello();" +
            "       System.out.println(hello.greeting());" +
            "   }" +
            "}";
        MemoryClassFactory factory = new MemoryClassFactoryImpl();
        Map sourceMap = new HashMap();
        sourceMap.put("test.Hello", helloSource);
        sourceMap.put("test.main.Main", mainSource);
        factory.setInput(sourceMap);
        JavaCompiler compiler = new JavaCompilerImpl();
        compiler.compile(new String[] {"test.main.Main"},
                         factory,
                         factory,
                         factory,
                         new JavaCompilerErrorHandler() {
                                 public void handleError(String className,
                                                         int line,
                                                         int column,
                                                         Object errorMessage) {
                                     String msg = className;
                                     if (line > 0) {
                                         msg += ": Line " + line;
                                     }
                                     if (column >= 0) {
                                         msg += "." + column;
                                     }
                                     msg += ": ";
                                     msg += errorMessage;
                                     System.err.println(msg);
                                 }
                             });
        
        Class clazz = factory.loadClass("test.main.Main");
        Runnable runner = (Runnable)clazz.newInstance();
        runner.run();
    }

}
