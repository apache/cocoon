/*
Copyright (c) 2002 Christopher Oliver

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
copies of the Software, and to permit persons to whom the Software is 
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in 
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
THE SOFTWARE.
*/
package example;
import org.tempuri.javac.JavaCompiler;
import org.tempuri.javac.JavaCompilerErrorHandler;
import org.tempuri.javac.JavaClassWriter;
import org.tempuri.javac.JavaClassWriterFactory;
import org.tempuri.javac.JavaClassReader;
import org.tempuri.javac.JavaClassReaderFactory;
import org.tempuri.javac.util.FileSystemClassFactory;
import java.util.Iterator;
import java.util.List;
import java.util.LinkedList;
import java.util.Map;
import java.util.HashMap;
import java.io.IOException;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
// Note: these could be dynamically loaded
import org.tempuri.javacImpl.eclipse.JavaCompilerImpl;
import org.tempuri.javacImpl.util.FileSystemClassFactoryImpl;

/**
 * Example that compiles and loads source files and runs the result.
 * <p/>
 * This example behaves like the <code>java</code> virtual machine 
 * launcher but doesn't require the code to be precompiled (it supports 
 * a "-sourcepath" as well as a "-classpath" option). It first compiles
 * and loads the source files in memory, and then executes the static 
 * <code>main(String[])</code> method of the class you specify, passing 
 * your command line arguments to it.
 * <p/>
 * For example, assuming you had a source file called "Echo.java" that
 * contained the following program:
 * <pre>
 * public class Echo {
 *    public static void main(String[] args) {
 *        for (int i = 0; i < args.length; i++) {
 *            System.out.println(args[i]);
 *        }
 *    }
 * }
 *
 * Invoking it from the command line could look something like this:
 *
 * % java example.Interpreter -sourcepath . Echo "Hello World!"
 * % Hello World!
 * </pre>
 */

public class Interpreter {

    private static void unknownOption(String option) {
	System.err.println("warning: unknown option: "+option);
    }

    private static void usage() {
	System.out.println("Usage: Interpreter <options> className <args>");
	
	System.out.println("where possible options include:");
	System.out.println("-classpath <path>         Specify where to find user class files");
	System.out.println("-sourcepath <path>        Specify where to find input source files");
	System.out.println("-bootclasspath <path>     Override location of bootstrap class files");
	System.out.println("-source <release>         Provide source compatibility with specified release");
	System.out.println("-target <release>         Generate class files for specific VM version");
	System.out.println("-help                     Print a synopsis of standard options");
    }

    /**
     * ClassLoader that implements findClass by using the
     * JavaCompiler API to locate and compile source files
     */

    static class CompilingClassLoader extends ClassLoader {

	public Class findClass(String className) 
	    throws ClassNotFoundException {
	    byte[] bytes = compile(className);
	    if (bytes == null) {
		throw new ClassNotFoundException(className);
	    }
	    return defineClass(className, bytes, 0,
			       bytes.length);
	}

	JavaCompiler compiler;
	FileSystemClassFactory fileSystem;
	Map output = new HashMap();

	CompilingClassLoader(JavaCompiler compiler,
			     FileSystemClassFactory fileSystem) {
	    this.compiler = compiler;
	    this.fileSystem = fileSystem;
	}

	class ClassReaderFactory 
	    implements JavaClassReaderFactory {

	    public JavaClassReader 
		getClassReader(final String className) 
		throws IOException {
		final byte[] bytes = 
		    (byte[])output.get(className);
		if (bytes != null) {
		    return new JavaClassReader() {
			    public String getClassName() {
				return className;
			    }
			    
			    public InputStream getInputStream() {
				
				return new ByteArrayInputStream(bytes);
			    }
			};
		}
		return fileSystem.getClassReader(className);
	    }
	}

	class ClassWriterFactory 
	    implements JavaClassWriterFactory {

	    public JavaClassWriter 
		getClassWriter(final String className) {
		return new JavaClassWriter() {
			public String 
			    getClassName() {
			    return className;
			}
			public void writeClass(InputStream contents) 
			    throws IOException {
			    byte[] buf = new byte[2048];
			    ByteArrayOutputStream s =
				new ByteArrayOutputStream();
			    int count;
			    while ((count = 
				    contents.read(buf, 0, 
						  buf.length)) > 0) {
				s.write(buf, 0, count);
			    }
			    s.flush();
			    System.out.print(className + " ");
			    output.put(className,
				    s.toByteArray());
			}
		    };
	    }
	}
	
	class ErrorHandler implements JavaCompilerErrorHandler {
	    public void handleError(String className,
				    int line,
				    int column,
				    Object errorMessage) {
		String msg = className;
		try {
		    // try to it convert to a file name
		    msg =
			fileSystem.makeFileName(className);
		} catch (IOException ignored) {
		    // oh well, I tried
		}
		if (line > 0) {
		    msg += ": Line " + line;
		}
		if (column >= 0) {
		    msg += "." + column;
		}
		msg += ": ";
		msg += errorMessage;
		System.err.println(msg);
	    }
	}

	private byte[] compile(String className) {
	    byte[] result = (byte[])output.get(className);
	    if (result != null) {
		return result;
	    }
	    // try to compile it
	    compiler.compile(new String[] {className},
			     fileSystem,
			     new ClassReaderFactory(),
			     new ClassWriterFactory(),
			     new ErrorHandler());
	    return (byte[])output.get(className);
	}
    }

    /**
     * Run the interpreter.
     * @param argv 
     * <pre>
     * &lt;options> className &lt;args>
     * where possible options include
     * </pre>
     * <ul>
     * <li>-classpath <path>         Specify where to find user class files</i>
     * <li>-sourcepath <path>        Specify where to find input source files</li>
     * <li>-bootclasspath <path>     Override location of bootstrap class files</li>
     * <li>-source <release>         Provide source compatibility with specified release</li>
     * <li>-target <release>         Generate class files for specific VM version</li>
     * <li>-help                     Print a synopsis of standard options</li>
     *
     * @throws Throwable
    */

    public static void main(String[] argv) throws Throwable {
	final FileSystemClassFactory fileSystem = 
	    new FileSystemClassFactoryImpl();
	List fileList = new LinkedList();
	String bootClassPath = System.getProperty("sun.boot.class.path");
	String classPath = System.getProperty("java.class.path");
	String sourcePath = ".";
	String className = null;
	List args = new LinkedList();
	boolean debug = true;
	String sourceVersion = null;
	String targetVersion = null;
	for (int i = 0; i < argv.length; i++) {
	    String arg = argv[i];
	    if (className == null && arg.startsWith("-")) {
		if (arg.equals("-sourcepath")) {
		    if ((i + 1) < argv.length) {
			sourcePath = argv[++i];
		    }
		} else if (arg.equals("-classpath") || arg.equals("-cp")) {
		    if ((i + 1) < argv.length) {
			classPath = argv[++i];
		    }
		} else if (arg.equals("-bootclasspath")) {
		    if ((i + 1) < argv.length) {
			bootClassPath = argv[++i];
		    }
		} else if (arg.equals("-source")) {
		    if ((i + 1) < argv.length) {
			sourceVersion = argv[++i];
		    }
		} else if (arg.equals("-target")) {
		    if ((i + 1) < argv.length) {
			targetVersion = argv[++i];
		    }
		} else if (arg.startsWith("-g")) {
		    debug = !arg.equals("-g:none");
		} else if (arg.equals("-help")) {
		    usage();
		    return;
		} else {
		    unknownOption(arg);
		}
	    } else {
		if (className == null) {
		    className = argv[i];
		} else {
		    args.add(argv[i]);
		}
	    }
	}
	if (className == null) {
	    usage();
	    return;
	}
	fileSystem.setBootClassPath(bootClassPath);
	fileSystem.setClassPath(classPath);
	fileSystem.setSourcePath(sourcePath);
        final JavaCompiler compiler = new JavaCompilerImpl();
	compiler.setDebug(debug);
	if (sourceVersion != null) {
	    compiler.setSourceVersion(sourceVersion);
	}
	if (targetVersion != null) {
	    compiler.setTargetVersion(sourceVersion);
	}
	/* 
	 * Create a class loader that compiles 
	 * source to locate missing classes
	 */
	CompilingClassLoader classLoader = 
	    new CompilingClassLoader(compiler, fileSystem);
	System.out.print("compiling ");
	Class clazz = classLoader.loadClass(className);
	System.out.println("");
	Method method = clazz.getMethod("main", 
					new Class[] {
					    String[].class
					});
	String[] newArgs = new String[args.size()];
	args.toArray(newArgs);
	try {
	    method.invoke(null, new Object[] {newArgs});
	} catch (InvocationTargetException e) {
	    throw e.getTargetException();
	}
    }
}

