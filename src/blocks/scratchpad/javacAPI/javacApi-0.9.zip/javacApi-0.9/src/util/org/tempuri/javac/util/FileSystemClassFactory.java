/*
Copyright (c) 2002 Christopher Oliver

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
copies of the Software, and to permit persons to whom the Software is 
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in 
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
THE SOFTWARE.
*/
package org.tempuri.javac.util;
import org.tempuri.javac.JavaClassReaderFactory;
import org.tempuri.javac.JavaClassReader;
import org.tempuri.javac.JavaClassWriterFactory;
import org.tempuri.javac.JavaClassWriter;
import org.tempuri.javac.JavaSourceReaderFactory;
import org.tempuri.javac.JavaSourceReader;
import java.io.IOException;

/**
 * Interface to a utility that simulates the behavior of <code>javac</code> 
 * in locating source files, compiled classes, and generating output.
 *
 */

public interface FileSystemClassFactory 
    extends JavaClassReaderFactory,
    JavaSourceReaderFactory, JavaClassWriterFactory {

    /**
     * Convert a file name to its associated Java class name 
     * @param fileName name of file
     * @return name of class
     */
    public String makeClassName(String fileName) throws IOException;

    /**
     * Convert a class name to its associated file name
     * @param className name of class
     * @return name of file
     */
    public String makeFileName(String className) throws IOException;

    /**
     * <pre>
     * Set the boot class path to use in locating compiled classes.
     * Equivalent to the "-bootclasspath" option of javac
     * </pre>
     * @param bcp string containing directory or jar file paths separated by the <code>java.io.File.pathSeparator</code>
     */
    public void setBootClassPath(String bcp);

    /**
     * <pre>
     * Set the class path to use in locating compiled classes.
     * Equivalent to the "-classpath" option of javac
     * </pre>
     * @param cp string containing directory or jar file paths separated by the <code>java.io.File.pathSeparator</code>
     */
    public void setClassPath(String cp);

    /**
     * <pre>
     * Set the source path to use in locating Java source files.
     * Equivalent to the "-sourcepath" option of javac.
     * </pre>
     * @param cp string containing directory or jar file paths separated by the <code>java.io.File.pathSeparator</code>
     */
    public void setSourcePath(String sp);
 
    /**
     * <pre>
     * Set the target directory for compiled output
     * Equivalent to the "-d" option of javac.
     * </pre>
     * @param outputDir string containing the root directory for generated class files
     */
    public void setOutputDir(String outputDir);
}


