/*
Copyright (c) 2002 Christopher Oliver

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
copies of the Software, and to permit persons to whom the Software is 
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in 
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
THE SOFTWARE.
*/
package org.tempuri.javac.util;
import org.tempuri.javac.JavaClassReaderFactory;
import org.tempuri.javac.JavaClassReader;
import org.tempuri.javac.JavaClassWriterFactory;
import org.tempuri.javac.JavaClassWriter;
import org.tempuri.javac.JavaSourceReaderFactory;
import org.tempuri.javac.JavaSourceReader;
import java.io.IOException;
import java.util.Map;

/**
 *
 * Interface to a utility object that supports compiling and loading Java
 * source code in memory
 * <pre>
 * Example:
 * JavaCompiler compiler = ...
 * JavaCompilerErrorHandler errorHandler = ...
 * MemoryClassFactory factory = ...
 * String source = "public class Foo { public void foo() {} }";
 * Map map = new HashMap();
 * map.put("Foo", source);
 * factory.setInput(map);
 * compiler.compile(factory, factory, factory, errorHandler);
 * Class clazz = factory.loadClass("Foo");
 * </pre>
 */

public interface MemoryClassFactory 
    extends JavaClassReaderFactory,
    JavaSourceReaderFactory, JavaClassWriterFactory {

    /**
     * Set the class loader to use to locate existing classes. If not 
     * set this defaults to the system class loader. The implementation
     * will use cl.getResource() or equivalent to attempt to locate an
     * existing class
     * @param cl class loader
     */
    public void setClassLoader(ClassLoader cl);

    /**
     * Set the input source files to be compiled. 
     * 
     * @param sourceMap a map of {className -> source code} pairs. Both the keys and values of the map must be instances of java.lang.String
     */
    public void setInput(Map sourceMap);

    /**
     * Get the compiled output files as a map
     * 
     * @return a map of {className -> compiled code} pairs. The keys in this map are instances of java.lang.String and the values are instances of byte[]
     */
    public Map getOutput();

    /**
     * Convenience method to load a class you just compiled in memory
     * @param name of class to load
     * @return The loaded class. The implementation will create a new class loader as a child of the class loader assigned in setClassLoader() to load the class.
     * @throws ClassNotFoundException
     */
    public Class loadClass(String className) throws ClassNotFoundException;

}


