/*
Copyright (c) 2002 Christopher Oliver

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
copies of the Software, and to permit persons to whom the Software is 
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in 
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
THE SOFTWARE.
*/
package org.tempuri.javac;

/**
 * Generic interface to a Java compilation system
 *
 */

public interface JavaCompiler {

    /**
     * Choose the target Java platform version, e.g "1.2", "1.3", or "1.4"
     * @param targetVersion 
     */
    public void setTargetVersion(String targetVersion)
        throws IllegalArgumentException;

    /**
     * Choose the Java source version, e.g "1.2", "1.3", or "1.4"
     * @param sourceVersion 
     */
    public void setSourceVersion(String sourceVersion)
        throws IllegalArgumentException;

    /**
     * Choose whether the compiler should include the line number table and
     * local variable table in generated class files
     * @param debug
     */
    public void setDebug(boolean debug);

    /**
     * Set source encoding
     * @param encoding 
     */
    public void setSourceEncoding(String encoding);

    /**
     * Compile a set of source classes. The compiler will attempt to compile
     * the transitive closure of all classes in this set. 
     * @param classNames list of classes to be compiled
     * @param sourceReaderFactory object used by compiler to locate source code
     * @param classReaderFactory object used by compiler to locate existing compiled classes
     * @param classWriterFactory object used by compiler to handle generated classes
     * @param errorHandler object used by compiler to handle errors
     */
    public void compile(String[] classNames,
                        JavaSourceReaderFactory sourceReaderFactory,
                        JavaClassReaderFactory classReaderFactory,
                        JavaClassWriterFactory classWriterFactory,
                        JavaCompilerErrorHandler errorHandler);
}
