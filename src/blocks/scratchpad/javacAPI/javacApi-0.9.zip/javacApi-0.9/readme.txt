This directory contains an experimental API and implementation for an 
embeddable Java compiler. For more information check the Javadoc's under 
the doc directory.

The implementation uses the eclipse.org Java Development Tools (JDT)
compiler: see http://www.eclipse.org for more information

The src/example/Javac.java example provides a partial simulation of
Sun's command line javac utility using this API. As a convenience on
Windows you can run this with the provided batch file javac.bat

The src/example/MemoryExample.java example provides a simple example of
compiling classes in memory and dynamically loading the result.
As a convenience on Windows you can run this with the provided batch 
file memoryExample.bat

The src/example/Interpreter.java example provides another example of
compiling classes in memory and dynamically loading the result.
As a convenience on Windows you can run this with the provided batch 
file interpret.bat

