/*
	Copyright (c) 2004-2006, The Dojo Foundation
	All Rights Reserved.

	Licensed under the Academic Free License version 2.1 or above OR the
	modified BSD license. For more information on Dojo licensing, see:

		http://dojotoolkit.org/community/licensing.shtml
*/

{
	now: new Date(),
	x: 1,
	y: 7,
	value: "I am a value",
	arrayOfNums: [1, 2, 3, 4, 5],
	toString: function() { return this.value + ", " + this.now; }
}
